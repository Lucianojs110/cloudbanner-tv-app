import React, { useState, useEffect } from "react";

// IMPORTÁ TUS ARCHIVOS
import ProductList1 from "./ProductListViews/ProductList1";
import ProductList2 from "./ProductListViews/ProductList2";
import ProductList3 from "./ProductListViews/ProductList3";
import ProductList4 from "./ProductListViews/ProductList4";
import ProductList5 from "./ProductListViews/ProductList5";
import ProductList10 from "./ProductListViews/ProductList10";

interface Media { original_url: string }
interface Product {
    id: number; name: string; description?: string | null;
    price: string; offer_price?: string | null; media?: Media[];
}
interface Customization {
    primary_color?: string; secondary_color?: string;
    background_type?: "box" | "degradado" | "imagen";
    font_family?: string; product_text_color?: string;
    price_text_color?: string; list_text_color?: string;
    list_text_box_color?: string; product_text_box_color?: string;
    pagination?: number; page_seconds?: number; other_texts?: string;
}
interface Props {
    title: string;
    products: Product[];
    customization: Customization;
    orientation?: "vertical" | "horizontal";
    rotationDirection?: "right" | "left";
    width?: number;
    height?: number;
}

export default function ProductListSlide({
    title,
    products,
    customization,
    orientation = "horizontal",
    rotationDirection = "right",
    width,
    height
}: Props) {
    const pagination = customization.pagination || 1;
    const pageSeconds = customization.page_seconds || 10;

    // Paginación por si hay más productos de los que se pueden mostrar
    const [page, setPage] = useState(0);

    useEffect(() => {
        if (products.length > pagination) {
            const timer = setInterval(() => {
                setPage((prev) => (prev + 1) % Math.ceil(products.length / pagination));
            }, pageSeconds * 1000);
            return () => clearInterval(timer);
        }
    }, [products.length, pagination, pageSeconds]);

    const productsToShow = products.slice(page * pagination, (page + 1) * pagination);

    // Dispatcher con width y height
    switch (productsToShow.length) {
        case 1:
            return <ProductList1 {...{ title, products: productsToShow, customization, orientation, rotationDirection, width, height }} />;
        case 2:
            return <ProductList2 {...{ title, products: productsToShow, customization, orientation, rotationDirection, width, height }} />;
        case 3:
            return <ProductList3 {...{ title, products: productsToShow, customization, orientation, rotationDirection, width, height }} />;
        case 4:
            return <ProductList4 {...{ title, products: productsToShow, customization, orientation, rotationDirection, width, height }} />;
        case 5:
            return <ProductList5 {...{ title, products: productsToShow, customization, orientation, rotationDirection, width, height }} />;
        case 10:
            return <ProductList10 {...{ title, products: productsToShow, customization, orientation, rotationDirection, width, height }} />;
        default:
            // Si no hay productos, mensaje default
            return (
                <ProductList1
                    title={title}
                    products={[]}
                    customization={customization}
                    orientation={orientation}
                    rotationDirection={rotationDirection}
                    width={width}
                    height={height}
                />
            );
    }
}
